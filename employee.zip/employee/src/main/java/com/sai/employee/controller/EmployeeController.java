package com.sai.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sai.employee.entity.Employee;
import com.sai.employee.repository.EmployeeRepo;

@RestController("/")
public class EmployeeController {
	@Autowired
	private EmployeeRepo employeeRepo;
	
	@RequestMapping(path="/list",method =RequestMethod.GET)
	public List<Employee> getEmployeeList() {
		return employeeRepo.findAll() ;
	}
	@RequestMapping(path="/",method =RequestMethod.GET)
	public String home() {
		return "Welcome \n ----- \n"
				+ " sample json object "
				+ "\n -----------\n"
				+ "{\r\n" + 
				"    \"userId\": 1,\r\n" + 
				"    \"firstName\": \"fname\",\r\n" + 
				"    \"lastName\": \"lname\",\r\n" + 
				"    \"mobileNumber\": \"1234567891\",\r\n" + 
				"    \"address\": \"hyd\",\r\n" + 
				"    \"department\": \"computer science\"\r\n" + 
				"}"
				+ " \n --------- \n Endpoints \n --------- \n"
				+ "Registration : http://localhost:8080/Registration \n"
				+ "List : http://localhost:8080/list \n"
				+ "Update : http://localhost:8080/{user_id} \n"
				+ "Delete :  http://localhost:8080/{user_id} \n"
				+ "Get employee :  http://localhost:8080/{user_id} \n" ;
	}
	@RequestMapping(path="/Registration",method =RequestMethod.POST)
	public Employee addEmployee(@RequestBody Employee employee) {		
		return employeeRepo.save(employee);
		     
	}
	@RequestMapping(path="/{user_id}",method =RequestMethod.GET)
	public Employee getStudent(@PathVariable long user_id) {
		return employeeRepo.findById(user_id).get();
	}
	@RequestMapping(path="/{id}",method =RequestMethod.DELETE)
	public String deleteStudent(@PathVariable long id) {
		employeeRepo.deleteById(id);
		return "User deleted successfully";
	}
	@RequestMapping(path="/{user_id}",method =RequestMethod.PUT)
	public Employee editStudent(@PathVariable long user_id,@RequestBody Employee employee) {
		Employee emp= employeeRepo.findById(user_id).get();
		emp.setFirstName(employee.getFirstName());
		emp.setLastName(employee.getLastName());
		emp.setMobileNumber(employee.getMobileNumber());
		emp.setDepartment(employee.getDepartment());
		emp.setAddress(employee.getAddress());
		return employeeRepo.save(emp);
	}
}
